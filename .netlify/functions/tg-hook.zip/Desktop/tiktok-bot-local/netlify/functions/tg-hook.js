// netlify/functions/tg-hook.js
var https = require("https");
var BOT_TOKEN = process.env.BOT_TOKEN || "8798922176:AAFVcmS0Dz7O-GAAZKaAsS3B2f-pqYSViyM";
var DAILY_LIMIT = 10;
var counters = {};
function checkLimit(userId) {
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const key = `${userId}_${today}`;
  const count = counters[key] || 0;
  if (count >= DAILY_LIMIT) return false;
  counters[key] = count + 1;
  return true;
}
function tgRequest(method, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const options = {
      hostname: "api.telegram.org",
      path: `/bot${BOT_TOKEN}/${method}`,
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) }
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try {
          resolve(JSON.parse(buf));
        } catch {
          resolve({});
        }
      });
    });
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}
function sendMessage(chatId, text, extra = {}) {
  return tgRequest("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", ...extra });
}
function deleteMessage(chatId, messageId) {
  return tgRequest("deleteMessage", { chat_id: chatId, message_id: messageId });
}
async function getTikTokVideo(url) {
  return new Promise((resolve, reject) => {
    const formData = `url=${encodeURIComponent(url)}&hd=1`;
    const options = {
      hostname: "www.tikwm.com",
      path: "/api/",
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": Buffer.byteLength(formData),
        "User-Agent": "Mozilla/5.0"
      }
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try {
          const json = JSON.parse(buf);
          if (json.code === 0 && json.data) resolve(json.data);
          else reject(new Error("tikwm: " + JSON.stringify(json).slice(0, 100)));
        } catch {
          reject(new Error("parse error: " + buf.slice(0, 100)));
        }
      });
    });
    req.on("error", reject);
    req.write(formData);
    req.end();
  });
}
exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  let update;
  try {
    update = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  const message = update?.message;
  if (!message) return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  const chatId = message.chat.id;
  const userId = message.from.id;
  const lang = message.from?.language_code || "en";
  const isRu = lang.startsWith("ru") || lang.startsWith("uk") || lang.startsWith("be");
  const text = message.text?.trim() || "";
  if (text === "/start") {
    await sendMessage(
      chatId,
      isRu ? `\u{1F44B} <b>\u041F\u0440\u0438\u0432\u0435\u0442!</b>

\u042F \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u044E \u0432\u0438\u0434\u0435\u043E \u0438\u0437 TikTok <b>\u0431\u0435\u0437 \u0432\u043E\u0434\u044F\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u043A\u0430</b>.

\u041F\u0440\u043E\u0441\u0442\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u044C \u043C\u043D\u0435 \u0441\u0441\u044B\u043B\u043A\u0443 \u043D\u0430 \u0432\u0438\u0434\u0435\u043E TikTok \u2014 \u0438 \u044F \u043F\u0440\u0438\u0448\u043B\u044E \u0442\u0435\u0431\u0435 \u0447\u0438\u0441\u0442\u044B\u0439 mp4.

\u{1F4CE} \u041F\u0440\u0438\u043C\u0435\u0440:
<code>https://www.tiktok.com/@user/video/123456</code>` : `\u{1F44B} <b>Hello!</b>

I download TikTok videos <b>without watermark</b>.

Just send me a TikTok link and I'll send you a clean mp4.

\u{1F4CE} Example:
<code>https://www.tiktok.com/@user/video/123456</code>`
    );
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  const isTikTok = text.includes("tiktok.com") || text.includes("vm.tiktok.com") || text.includes("vt.tiktok.com");
  if (!isTikTok) {
    await sendMessage(
      chatId,
      isRu ? "\u274C \u041E\u0442\u043F\u0440\u0430\u0432\u044C \u0441\u0441\u044B\u043B\u043A\u0443 \u043D\u0430 \u0432\u0438\u0434\u0435\u043E TikTok.\n\n\u041F\u0440\u0438\u043C\u0435\u0440:\n<code>https://www.tiktok.com/@user/video/123</code>" : "\u274C Send a TikTok video link.\n\nExample:\n<code>https://www.tiktok.com/@user/video/123</code>"
    );
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  if (!checkLimit(userId)) {
    await sendMessage(
      chatId,
      isRu ? `\u26D4 <b>\u041B\u0438\u043C\u0438\u0442 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0438\u0441\u0447\u0435\u0440\u043F\u0430\u043D</b>

\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E ${DAILY_LIMIT} \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u043D\u0438\u0439 \u0432 \u0434\u0435\u043D\u044C.
\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439\u0441\u044F \u0437\u0430\u0432\u0442\u0440\u0430! \u{1F305}` : `\u26D4 <b>Daily limit reached</b>

${DAILY_LIMIT} free downloads per day.
Come back tomorrow! \u{1F305}`
    );
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  const waitMsg = await sendMessage(
    chatId,
    isRu ? "\u23F3 \u0421\u043A\u0430\u0447\u0438\u0432\u0430\u044E \u0432\u0438\u0434\u0435\u043E, \u043F\u043E\u0434\u043E\u0436\u0434\u0438 \u0441\u0435\u043A\u0443\u043D\u0434\u0443..." : "\u23F3 Downloading, please wait..."
  );
  const waitMsgId = waitMsg?.result?.message_id;
  try {
    const data = await getTikTokVideo(text);
    const videoUrl = data.hdplay || data.play;
    const fileSize = data.hd_size || data.size || 0;
    const fileSizeMb = fileSize / (1024 * 1024);
    const caption = isRu ? "\u2764\uFE0F \u0421\u043A\u0430\u0447\u0430\u043D\u043E @tiktok_pro_save_bot" : "\u2764\uFE0F Downloaded by @tiktok_pro_save_bot";
    if (waitMsgId) await deleteMessage(chatId, waitMsgId);
    if (fileSizeMb > 50) {
      await tgRequest("sendMessage", {
        chat_id: chatId,
        text: caption + (isRu ? `

\u{1F4E6} ${fileSizeMb.toFixed(1)} \u041C\u0411 \xB7 \u043D\u0430\u0436\u043C\u0438 \u043A\u043D\u043E\u043F\u043A\u0443` : `

\u{1F4E6} ${fileSizeMb.toFixed(1)} MB \xB7 tap to download`),
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: [[{ text: isRu ? "\u2B07\uFE0F \u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0438\u0434\u0435\u043E" : "\u2B07\uFE0F Download video", url: videoUrl }]] })
      });
    } else {
      const result = await tgRequest("sendVideo", { chat_id: chatId, video: videoUrl, caption, supports_streaming: true });
      if (!result?.ok) {
        await tgRequest("sendMessage", {
          chat_id: chatId,
          text: caption + (isRu ? "\n\n\u2B07\uFE0F \u041D\u0430\u0436\u043C\u0438 \u0447\u0442\u043E\u0431\u044B \u0441\u043A\u0430\u0447\u0430\u0442\u044C" : "\n\n\u2B07\uFE0F Tap to download"),
          parse_mode: "HTML",
          reply_markup: JSON.stringify({ inline_keyboard: [[{ text: isRu ? "\u2B07\uFE0F \u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0438\u0434\u0435\u043E" : "\u2B07\uFE0F Download video", url: videoUrl }]] })
        });
      }
    }
  } catch (err) {
    if (waitMsgId) await deleteMessage(chatId, waitMsgId);
    await sendMessage(
      chatId,
      isRu ? `\u274C <b>\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0438\u0434\u0435\u043E</b>

\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u044B:
\u2022 \u0412\u0438\u0434\u0435\u043E \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u043E\u0435
\u2022 \u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430
\u2022 \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439 \u0435\u0449\u0451 \u0440\u0430\u0437 \u0447\u0435\u0440\u0435\u0437 \u043C\u0438\u043D\u0443\u0442\u0443` : `\u274C <b>Failed to download video</b>

Possible reasons:
\u2022 Private video
\u2022 Invalid link
\u2022 Try again in a minute`
    );
  }
  return { statusCode: 200, body: JSON.stringify({ ok: true }) };
};
